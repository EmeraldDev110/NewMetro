{{--
  Template Name: Typeform Template
--}}

@extends('layouts.app')

@section('content')
    @include('pages.typeform.form')
@endsection
