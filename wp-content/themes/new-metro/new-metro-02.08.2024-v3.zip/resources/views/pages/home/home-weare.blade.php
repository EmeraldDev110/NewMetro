<section class="home-weare">
    <span class="title-question">Why pay an agent?</span>
    <h1 class="title-answer">We’re your buyer!</h1>
    <a href="{{ home_url('/contact') }}">
        <button class="purple">Start Here</button>
    </a>
</section>