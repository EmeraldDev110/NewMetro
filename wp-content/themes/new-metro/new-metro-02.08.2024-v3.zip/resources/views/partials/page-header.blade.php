<div class="page-header">
  <img class="decoration-default-left" src="@asset('images/decoration-top.png')" alt="">
  <h1>{!! App::title() !!}</h1>
  <img class="decoration-default-right" src="@asset('images/decoration-bottom.png')" alt="">
</div>
