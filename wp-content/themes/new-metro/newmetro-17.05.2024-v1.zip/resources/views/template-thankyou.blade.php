{{--
  Template Name: ThankYou Template
--}}

@extends('layouts.app')

@section('content')
    @include('pages.thankyou.content')
@endsection