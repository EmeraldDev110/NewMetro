<header class="banner">
  <nav class="navbar">
    <a href="{{ home_url('/') }}">
      <img class="navbar-logo" src="@asset('images/logo.svg')" alt="Logo">
    </a>
    <img class="navbar-certification" src="@asset('images/certification.svg')" alt="Certification">
  </nav>
</header>
